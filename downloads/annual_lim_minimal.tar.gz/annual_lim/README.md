# North Atlantic pure LIM source

This package contains the CMIP6 preprocessing, twelve-month EOF/LIM training, and NumPy or PyTorch sampling commands. Each month has its own parameters. Give the trained model a calendar date, an annual warming level in kelvin above 1850–1900, and a random seed. The example uses September 2050 at +2 K. [Worked tutorials and figures](https://github.com/ZhanxiangHua/north-atlantic-pure-lim/tree/main/notebooks) · [Model equations](https://github.com/ZhanxiangHua/north-atlantic-pure-lim/blob/main/experiments/annual_refinement/METHODS.md)

## Run the fitted model

From the extracted directory, use Python 3.11 or later. Get the published base weights and the twelve small changes used by the research model. Restoration checks the SHA-256 digest and identity of each month.

~~~bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
curl -fL -o annual_lim_v1.tar.gz \
  https://github.com/ZhanxiangHua/north-atlantic-pure-lim/releases/download/v1.0.0/annual_lim_full.tar.gz
tar -xzf annual_lim_v1.tar.gz --strip-components=1 annual_lim/weights
curl -fL --output 'checkpoints/annual_refinement/#1.delta.zip' \
  'https://raw.githubusercontent.com/ZhanxiangHua/north-atlantic-pure-lim/main/checkpoints/annual_refinement/[01-12].delta.zip'
python experiments/annual_refinement/checkpoint.py restore --base weights \
  --delta checkpoints/annual_refinement --output work/refined_weights
python run.py sample --weights work/refined_weights --month 9 --year 2050 \
  --g 2 --days 15 --seed 417 --output work/september.nc
~~~

For all twelve months, use `python run.py sample-year --weights work/refined_weights --year 2050 --g 2 --seed 417 --output work/annual.nc`. The annual file has one wind map per day and one ocean–atmosphere background per month. The default backend is NumPy. Add `--device cpu` for PyTorch on CPU.

## Train from MPI fields

The catalogue in `configs/annual_lim` locates MPI-ESM1-2-LR historical and SSP5-8.5 ocean, atmospheric and daily wind fields. The prepare command checks input files and constructs twelve aligned physical maps and daily wind series for each member-year. Training uses the original published model as its reference and rebuilds the selected 57-year recipe.

~~~bash
python -m pip install -r experiments/annual_refinement/requirements.txt
source experiments/annual_refinement/env.sh
"$TC_PYTHON" experiments/annual_refinement/retrain.py \
  --recipe reports/annual_refinement/recipe.json --baseline-weights weights \
  --stage prepare --workers 2
"$TC_PYTHON" experiments/annual_refinement/retrain.py \
  --recipe reports/annual_refinement/recipe.json --baseline-weights weights \
  --stage train --workers 2
~~~

The training command prints the path to the new weights. Use that directory with the same sampling commands. The core CLI also exposes the original v1 training pipeline through `run.py prepare`, `run.py train`, and `run.py validate`. [Training data, independent evaluation and reproducibility](https://github.com/ZhanxiangHua/north-atlantic-pure-lim/blob/main/reports/annual_refinement/DATA.md)
